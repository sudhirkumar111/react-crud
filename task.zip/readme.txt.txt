To start server:
	1. got to backend folder 
	2. npm start

To start Client:
	1. go to frontend folder
	2. npm start

