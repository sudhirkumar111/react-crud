import React from 'react'

const Contact = () => {
    return (
        <>

            {/* <img className='text-center' src='https://cdn.pixabay.com/photo/2019/01/15/11/09/time-3933842_1280.jpg' width="800px" height="300px"></img> */}
            <div id="tms" className='bg-light w-50 text-center mx-auto p-5 mt-5'>
                <h1 className='display-6 text-primary'>Please Feel Free To Contact</h1>
                <p>Name : Sudhir Kumar</p>
                <p>Phone : +91 9649917443</p>
                <p>Email : connect.sudhirkumar@gmail.com</p>

            </div>

        </>
    )

}


export default Contact