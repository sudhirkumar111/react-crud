import React from 'react'

const PageNotFound=()=>{
    return(
        <>
        <h1 className='display-4 '>This Page is not available</h1>
        <p className='display-6 text-danger'>Error 404</p>
        </>
    )

}


export default PageNotFound